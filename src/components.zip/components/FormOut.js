import React from "react";
import RadioBtn from './RadioBtn';
import "./FormOut.css";
function FormOut() {
    let formStyle = {
        margin: "15px",
      }
    return (
        <section className="chatbox">
            <div className="chat-input-holder">
                <div className="card text-center w-50 p-3 mx-auto">
                    <div className="card-header">
                        <h2>Upload your Files</h2>
                    </div>
                    <div className="card-body">
                        <div className="dropdown">
                            <a className="btn btn-primary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Choose subject
                            </a>
                            <ul className="dropdown-menu">
                                <li><a className="dropdown-item" href="#">Mathematics</a></li>
                                <li><a className="dropdown-item" href="#">Physics</a></li>
                                <li><a className="dropdown-item" href="#">Chemistry</a></li>
                            </ul>
                        </div>
                        <form action="GET" style={formStyle}>
                            <input type="file" id="myFile" name="filename" /><br />
                        </form>
                    </div>
                    <RadioBtn />
                    <div className="card-footer text-body-primary">
                        <input type="submit" className="btn btn-info" />
                    </div>
                </div>

            </div>
        </section>
    );
}
export default FormOut;