// import React, { useState } from "react";
// import "./SelectSubject.css";

// function SelectSubject({ subjects }) {
//   const [isOpen, setIsOpen] = useState(false);

//   const toggleDropdown = () => {
//     setIsOpen(!isOpen);
//   };

//   return (
//     <div className="Select-subject">
//       <hr className="hline" />
//       <div className="dropdown">
//         <button className="btn btn-primary dropdown-toggle btn1" onClick={toggleDropdown}> Select subjects </button>
//         {isOpen && (
//           <ul className="dropdown-menu">
//             {subjects.map((subject, index) => (
//               <li key={index}>
//                 {console.log(subject)}
//                 <a className="dropdown-item" href="#">{subject}</a>
//               </li>
//             ))}
//           </ul>
//         )}
//       </div>
//     </div>
//   );
// }

// export default SelectSubject;



import React, { useState } from "react";
import "./SelectSubject.css";

function SelectSubject({ subjects }) {
  const [isCollapsed, setIsCollapsed] = useState(true);

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <div className="Select-subject">
      <hr className="hline" />
      <div className="collapse-button">
        <button className="btn btn-primary" onClick={toggleCollapse}>
          {isCollapsed ? "Select subject" : "Hide subjects"}
        </button>
      </div>
      {!isCollapsed && (
        <ul className="subject-list">
          {subjects.map((subject, index) => (
            <li key={index}>{subject}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default SelectSubject;

